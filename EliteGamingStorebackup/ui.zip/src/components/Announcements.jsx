import React from 'react'
import styled from 'styled-components'


const Container = styled.div`
height:30px;
background-color:dodgerblue;
color:white;
display:flex;
align-items:center;
justify-content:center;
`
const Announcements = () => {
  return (
    <Container>Super deal! Free shiping on orders over 50$ </Container>
  )
}

export default Announcements