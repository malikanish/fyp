

;export const categories = [
    {
      id: 1,
      img: "../images/accessories.jpg",
      title: "ACCESSORIES!",
    },
    {
      id: 2,
      img: "../images/graphic.jpg",
      title: "GRAPHIC CARDS",
    },
    {
      id: 3,
      img: "../images/package.png",
      title: "PACKAGES",
    },
  ];

  
  export const popularProducts = [
    {
      id:1,
      img:"../images/gamingmouse.png",
    },
    {
      id:2,
      img:"../images/console.jpg",
    },
    {
      id:3,
      img:"../images/keyboard.jpg",
    },
    {
      id:4,
      img:"../images/Master.jpg",
    },
    {
      id:5,
      img:"../images/tower.jpg",
    },
    {
      id:6,
      img:"../images/powersupply.jpg",
    },
    {
      id:7,
      img:"../images/led.jpg",
    },
    {
      id:8,
      img:"../images/motherboard.jpg",
    },
  ]

